//import './App.css'
import "@mantine/core/styles.css";

import { MantineProvider } from "@mantine/core";
import KitchenMap from "./components/KitchenMap";

function App() {
  return (
    <MantineProvider>
      <KitchenMap />
    </MantineProvider>
  );
}

export default App;
