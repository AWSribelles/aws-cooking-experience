export const appConfig = {
  // MODULE 1- BACKEND
  initStateAPI:
    "https://wfzane48g3.execute-api.us-west-2.amazonaws.com/Prod/InitState/",
  // MODULE 2 - REALTIME
  iot: {
    poolId: "us-west-2:1c8b7b56-cfb4-4931-b43b-a16c1612f5f4",
    host: "aivw4eqcifqkl-ats.iot.us-west-2.amazonaws.com",
    region: "us-west-2",
  },
  // MODULE 3 - PHOTOS
  photoUploadURL:
    "https://wfzane48g3.execute-api.us-west-2.amazonaws.com/Prod/Upload",
  // MODULE 4 - GENAI
  describeImageAPI: "https://r9fyzlfrm2.execute-api.us-west-2.amazonaws.com/Prod/describeimage",
};
