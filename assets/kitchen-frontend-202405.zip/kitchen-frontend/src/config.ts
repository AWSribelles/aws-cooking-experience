export const appConfig = {
  // MODULE 1- BACKEND
  initStateAPI: "",
  // MODULE 2 - REALTIME
  iot: {
    poolId: "",
    host: "",
    region: "",
  },
  // MODULE 3 - PHOTOS
  photoUploadURL: "",
  // MODULE 4 - GENAI
  describeImageAPI: "",
};
