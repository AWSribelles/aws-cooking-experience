import { Route, Routes } from "react-router-dom";
import PageKitchen from "./pages/Kitchen";

export function MyRoutes() {
    return (
        <Routes>
            <Route path="/" element={<PageKitchen/>} />
        </Routes>
    )
}