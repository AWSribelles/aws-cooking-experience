import KitchenMap from "../components/KitchenMap";

export default function PageKitchen() {
    return <>
        <KitchenMap></KitchenMap>
    </>
}