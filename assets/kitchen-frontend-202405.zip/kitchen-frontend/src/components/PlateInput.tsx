import {
  Button,
  Container,
  FileButton,
  Notification,
  Stack,
} from "@mantine/core";
import { useEffect, useState } from "react";
import { appConfig } from "../config";
import axios from "axios";

export default function PlateInput() {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<"start" | "loading" | "succeeded" | "error">("start");

  useEffect(() => {
    console.log(file);
    if (file) {
      uploadImage();
    }
  }, [file]);

  async function uploadImage() {
    setStatus("loading")
    try {
      const presignedUrl = await axios({
        method: "GET",
        url: appConfig.photoUploadURL,
      });
      await axios({
        method: "PUT",
        url: presignedUrl.data.uploadURL,
        data: file,
      });
      setStatus("succeeded")
    } catch (error) {
      setStatus("error")
      console.error(error);
    }
  }

  return (
    <>
      <Container style={{ zIndex: 999 }}>
        <Stack>
          <FileButton onChange={setFile} accept="image/png,image/jpeg">
            {(props) => <Button {...props}>Upload image</Button>}
          </FileButton>
        </Stack>
        <Notification withCloseButton={false}
          title={
            status === "start"
              ? "pick an image"
              : status === "loading"
              ? "uploading..."
              : status === "succeeded"
              ? "done!"
              : "error!"
          }
          color={status === "start"
          ? undefined
          : status === "loading"
          ? "yellow"
          : status === "succeeded"
          ? "green"
          : "red"}
          loading={status === "loading"}
        ></Notification>
      </Container>
    </>
  );
}
