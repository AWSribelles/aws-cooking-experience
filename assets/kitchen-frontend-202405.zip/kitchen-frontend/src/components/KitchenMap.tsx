"use client";
import { LatLngBoundsExpression } from "leaflet";
import { ImageOverlay, Marker, useMap } from "react-leaflet";
import { MapContainer } from "react-leaflet/MapContainer";
import "leaflet/dist/leaflet.css";
import "./map.css";
import React, { useEffect, useState } from "react";

import L from "leaflet";
import {
  Card,
  Group,
  Image,
  MantineProvider,
  Modal,
  Text,
} from "@mantine/core";
import { renderToString } from "react-dom/server";
import { appConfig } from "../config";
import IoT from "./IoT";
import { useDisclosure } from "@mantine/hooks";
import PlateInput from "./PlateInput";
import { Ingredient } from "./types";
import Gallery from "./Gallery";
import { getInitState } from "./initState";

React.useLayoutEffect = React.useEffect;

const Refresh = ({ ts }: { ts: Date }) => {
  const map = useMap();
  useEffect(() => {
    map.invalidateSize();
  }, [ts]);
  return null;
};
export default function KitchenMap() {
  const bounds: LatLngBoundsExpression = [
    [47.5442, -10.1469],
    [49.6442, -15.1469],
  ];
  const [refreshTs, _] = useState(new Date());
  const [
    addPhotoModal,
    { open: openAddPhotoModal, close: closeAddPhotoModal },
  ] = useDisclosure(false);
  const [galleryModal, { open: openGalleryModal, close: closeGalleryModal }] =
    useDisclosure(false);

  async function init() {
    try {
      if (!appConfig.initStateAPI) {
        return;
      }
      const { ingredientsData } = await getInitState();
      setIngredients(ingredientsData);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    init();
  }, []);

  const [ingredients, setIngredients] = useState<Ingredient[]>([]);

  return (
    <>
      {appConfig.iot.host && appConfig.iot.poolId && appConfig.iot.region ? (
        <IoT setIngredients={setIngredients}></IoT>
      ) : undefined}
      <MapContainer
        center={[48.5942, -12.1469]}
        bounds={bounds}
        maxBounds={bounds}
        attributionControl={false}
        minZoom={8}
        zoom={9}
        //ref={setMap}
        style={{ zIndex: 1 }}
      >
        <Refresh ts={refreshTs}></Refresh>
        <ImageOverlay url="/images/kitchen1.png" bounds={bounds}></ImageOverlay>
        {appConfig.photoUploadURL ? (
          <Marker
            position={[48.5942, -12.1469]}
            eventHandlers={{
              click: () => {
                openAddPhotoModal();
              },
            }}
            icon={L.divIcon({
              html: renderToString(
                <MantineProvider>
                  <Image
                    src="images/camera.png"
                    height={80}
                    alt="camera"
                  ></Image>
                </MantineProvider>
              ),
              className: "dummy",
            })}
          ></Marker>
        ) : undefined}
        {appConfig.photoUploadURL ? (
          <Marker
            position={[48.5942, -13.0469]}
            eventHandlers={{
              click: () => {
                openGalleryModal();
              },
            }}
            icon={L.divIcon({
              html: renderToString(
                <MantineProvider>
                  <Image src="images/menu.png" height={80} alt="menu"></Image>
                </MantineProvider>
              ),
              className: "dummy",
            })}
          ></Marker>
        ) : undefined}
        {ingredients.map((area, index) => {
          return (
            <Marker
              key={index}
              position={area.contentPosition}
              icon={L.divIcon({
                html: renderToString(
                  <MantineProvider>
                    <Card
                      style={{
                        width: "12em",
                        opacity: "0.9",
                      }}
                    >
                      <Card.Section
                        style={{
                          backgroundColor: area.inService
                            ? "#88cc88"
                            : "#cc8888",
                          paddingRight: "5px",
                        }}
                      >
                        <Group wrap="nowrap">
                          <Image
                            src={area.image}
                            height={40}
                            alt={area.header}
                          />
                          <div>
                            <Text size="sm" fw={500}>
                              {area.header}
                            </Text>
                          </div>
                        </Group>
                      </Card.Section>

                      {!area.inService ? (
                        <Text
                          size="xs"
                          style={{
                            color: area.inService ? "#88cc88" : "#cc8888",
                          }}
                        >
                          Stock {area.inService ? "available" : "unavilable"}
                        </Text>
                      ) : undefined}

                      {area.inService && area.wait ? (
                        <Text size="xs">Prepared in {area.wait} min</Text>
                      ) : undefined}
                    </Card>
                  </MantineProvider>
                ),
                className: "dummy",
              })}
            ></Marker>
          );
        })}
      </MapContainer>
      <Modal
        opened={addPhotoModal}
        onClose={closeAddPhotoModal}
        title="Add photo"
      >
        <PlateInput></PlateInput>
      </Modal>
      <Modal
        opened={galleryModal}
        onClose={closeGalleryModal}
        title="Gallery"
        fullScreen
      >
        <Gallery></Gallery>
      </Modal>
    </>
  );
}
