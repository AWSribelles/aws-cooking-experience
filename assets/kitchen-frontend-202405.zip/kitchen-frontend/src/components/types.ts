import { LatLngExpression } from "leaflet";

export interface UserPhoto {
  objectKey: string;
  partitionKey: "user-photo";
  sortKey: string;
  URL: string;
}

export interface WaitTimes {
  sortKey: "waittimes";
  partitionKey: "config";
  message: string;
}
export interface WaitTimeEntry {
  rideId: string;
  inService: boolean;
  wait: number;
  lastUpdated: number;
}

interface VarLocation {
  map: string;
  partitionKey: "locations";
  sortKey: string;
  name: string;
  type: "restroom" | "atm" | "dining";
}

export interface IngredientInput {
  partitionKey: "locations";
  sortKey: string;
  image: string;
  map: string;
  thumbnail: string;
  name: string;
  type: "ingredient";
}

export type InitState = (UserPhoto | WaitTimes | VarLocation | IngredientInput)[];

export interface Ingredient {
  id: string;
  header: string;
  wait: string;
  inService: boolean;
  contentPosition: LatLngExpression;
  image: string;
  thumbnail: string;
}

export interface WaitTimesEntry {
  rideId: string;
  inService: boolean;
  wait: number;
  lastUpdated: number;
}
