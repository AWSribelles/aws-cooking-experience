import { useEffect, useRef, useState } from "react";
import { getInitState } from "./initState";
import "react-image-gallery/styles/css/image-gallery.css";
import ImageGallery from "react-image-gallery";
import { UserPhoto } from "./types";
import {
  Box,
  Button,
  Flex,
  Grid,
  Image,
  Stack,
  Text,
  TextInput,
  Textarea,
} from "@mantine/core";
import axios from "axios";
import { appConfig } from "../config";
import { jsPDF } from "jspdf";

export default function Gallery() {
  const [photos, setPhotos] = useState<
    { original: string; thumbnail: string }[]
  >([]);
  const galleryRef = useRef<ImageGallery | null>(null);
  const [prompt, setPrompt] = useState("");
  const [promptResult, setPromptResult] = useState(``);
  const [describeApiActive, setDescribeApiActive] = useState(false);
  const [dishName, setDishName] = useState("");

  async function init() {
    const { userPhotos } = await getInitState();
    console.log(userPhotos);
    const galleryPhotos = (userPhotos as UserPhoto[]).map((item) => {
      return {
        original: item.URL,
        thumbnail: item.URL,
      };
    });
    setPhotos(galleryPhotos);
  }

  async function callDescribeApi() {
    if (galleryRef.current) {
      setDescribeApiActive(true);

      const photo = photos[galleryRef.current?.getCurrentIndex()];
      const fileName = photo.original.split("/").pop();

      const response = await axios({
        method: "POST",
        url: appConfig.describeImageAPI,
        params: {
          s3_key: encodeURIComponent(fileName!),
          prompt: encodeURIComponent(prompt),
        },
      });
      setPromptResult(response.data.content[0].text);

      setDescribeApiActive(false);
    }
  }

  async function generatePdf() {
    const doc = new jsPDF({
      format: "a4",
      compress: true,
    });
    const docWidth = doc.internal.pageSize.getWidth();
    const docHeight = doc.internal.pageSize.getHeight();


    const headerElement = document.getElementById(
      "unicorn-header"
    ) as HTMLImageElement;
    const headerCanvas = document.createElement("canvas")
    headerCanvas.width = 1405
    headerCanvas.height = 480
    const headerCtx = headerCanvas.getContext("2d")
    if (headerCtx) {
      headerCtx.drawImage(headerElement, 0, 0)
      doc.addImage(
        headerCtx.getImageData(0, 0, headerCanvas.width, headerCanvas.height),
        "PNG",
        0,
        0,
        docWidth,
        docWidth / headerCanvas.width  * headerCanvas.height,
        undefined,
        "SLOW"
      );
    }

    doc.setFontSize(24).text(dishName, docWidth/2, 85, {
      align: "center",
    })

    const imageGallerySlides = document.getElementsByClassName(
      "image-gallery-slides"
    )[0];
    const imageElement = imageGallerySlides.children[
      galleryRef.current!.getCurrentIndex()
    ].children[0] as HTMLImageElement;
    imageElement.crossOrigin = "anonymous";

    const canvas = document.createElement("canvas");
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext("2d");

    if (ctx) {
      ctx.drawImage(imageElement, 0, 0);
      doc.addImage(
        ctx.getImageData(0, 0, canvas.width, canvas.height),
        "JPEG",
        docWidth * 0.3,
        95,
        docWidth * 0.4,
        docWidth * 0.4,
        undefined,
        "SLOW"
      );
    }

    const cookingLabImage = document.getElementById(
      "cloud-cooking-lab"
    ) as HTMLImageElement;
    cookingLabImage.crossOrigin = "anonymous";
    const cookingLabCanvas = document.createElement("canvas");
    cookingLabCanvas.width = 1526;
    cookingLabCanvas.height = 1329;
    const cookingLabCtx = cookingLabCanvas.getContext("2d");

    if (cookingLabCtx) {
      cookingLabCtx.fillStyle = "white";
      cookingLabCtx.fillRect(
        0,
        0,
        cookingLabCanvas.width,
        cookingLabCanvas.height
      );
      cookingLabCtx.drawImage(cookingLabImage, 0, 0);
      doc.addImage(
        cookingLabCtx.getImageData(
          0,
          0,
          cookingLabCanvas.width,
          cookingLabCanvas.height
        ),
        "PNG",
        20,
        100,
        cookingLabCanvas.width * 0.02,
        cookingLabCanvas.height * 0.02,
        undefined,
        "SLOW",
        30
      );
    }

    const splitText = doc.setFontSize(10).splitTextToSize(promptResult, 180);
    doc.text(splitText, 15, 190);

    doc.text("powered by Amazon Bedrock", docWidth-60, docHeight-10)

    doc.save("a4.pdf");
  }

  useEffect(() => {
    init();
  }, []);
  return (
    <>
    <Image id="unicorn-header" src={"images/header.png"} style={{
      display: "none"
    }}></Image>
      <Flex justify={"flex-end"}>
        <Image
          id="cloud-cooking-lab"
          src="images/Cloud_Cooking_Classes.png"
          style={{
            height: "auto",
            width: "auto",
            maxWidth: "8em",
            maxHeight: "8em",
            marginRight: "12em",
          }}
        ></Image>
      </Flex>

      <Grid align="center" justify="center">
        <Grid.Col span={3}>
          <ImageGallery
            items={photos}
            ref={galleryRef}
            showPlayButton={false}
            thumbnailPosition="top"
          ></ImageGallery>
        </Grid.Col>
        {appConfig.describeImageAPI ? (
          <Grid.Col span={3}>
            <Stack>
              <TextInput
                value={dishName}
                onChange={(e) => {
                  setDishName(e.currentTarget.value);
                }}
                label="Dish name"
                maxLength={50}
              ></TextInput>
              <Textarea
                value={prompt}
                onChange={(event) => setPrompt(event.currentTarget.value)}
                label="Prompt"
                description="Tell the AI how you'd like it to describe the image."
              ></Textarea>
              <Button
                loading={describeApiActive}
                disabled={!prompt || describeApiActive}
                onClick={() => callDescribeApi()}
              >
                Describe
              </Button>
            </Stack>
          </Grid.Col>
        ) : undefined}

        <Grid.Col span={3}>
          {appConfig.describeImageAPI && promptResult ? (
            <Stack>
              <Box>
                <Text size="xs">{promptResult}</Text>
              </Box>
              <Button disabled={!promptResult} onClick={() => generatePdf()}>
                Generate PDF
              </Button>
            </Stack>
          ) : undefined}
        </Grid.Col>
      </Grid>
    </>
  );
}
