import axios from "axios";
import { appConfig } from "../config";
import {
  Ingredient,
  IngredientInput,
  InitState,
  WaitTimeEntry,
  WaitTimes,
} from "./types";

export async function getInitState() {
  const response = await axios.get(appConfig.initStateAPI);
  const initState = response.data.result.Items as InitState;
  console.log("initState", initState);

  const userPhotos = initState.filter(
    (item) => item.partitionKey === "user-photo"
  );

  let waitTimes: {
    [key: string]: {
      inService: boolean;
      wait: number;
      lastUpdated: number;
    };
  } = {};
  const waitTimesObject = initState.find(
    (item) => item.sortKey === "waittimes"
  ) as WaitTimes;
  if (waitTimesObject && waitTimesObject.message) {
    waitTimes = (
      JSON.parse(
        (initState.find((item) => item.sortKey === "waittimes") as WaitTimes)
          .message
      ) as WaitTimeEntry[]
    ).reduce((prev, curr) => {
      prev[curr.rideId] = {
        inService: curr.inService,
        wait: curr.wait,
        lastUpdated: curr.lastUpdated,
      };
      return prev;
    }, {} as { [key: string]: { inService: boolean; wait: number; lastUpdated: number } });
  } else {
    waitTimes = {};
  }

  const displayData = (
    initState.filter(
      (item) => item.partitionKey === "locations"
    ) as IngredientInput[]
  ).reduce(
    (prev, curr) => {
      const map = JSON.parse(curr.map) as {
        lat: { N: number };
        lng: { N: number };
      };
      prev[curr.sortKey] = {
        name: curr.name,
        type: curr.type,
        map: [map.lat.N, map.lng.N],
        thumbnail: curr.thumbnail,
        image: curr.image,
      };
      return prev;
    },
    {} as {
      [key: string]: {
        name: string;
        type: string;
        map: [number, number];
        thumbnail: string;
        image: string;
      };
    }
  );

  const ingredientsData: Ingredient[] = [];
  for (const initStateItem of initState) {
    if ("type" in initStateItem && initStateItem.type === "ingredient") {
      ingredientsData.push({
        id: initStateItem.sortKey,
        header: initStateItem.name,
        wait: waitTimes[initStateItem.sortKey] ? String(waitTimes[initStateItem.sortKey].wait) : "",
        inService: waitTimes[initStateItem.sortKey] ? waitTimes[initStateItem.sortKey].inService : true,
        contentPosition: displayData[initStateItem.sortKey].map,
        image: displayData[initStateItem.sortKey].image,
        thumbnail: displayData[initStateItem.sortKey].thumbnail,
      });
    }
  }

  return {
    ingredientsData,
    waitTimes,
    displayData,
    userPhotos,
  };
}
