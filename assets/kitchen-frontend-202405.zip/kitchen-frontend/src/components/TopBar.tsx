import { Image } from "@mantine/core";

export default function TopBar() {
    return <>
    <Image></Image>
    </>
}