import { fromCognitoIdentityPool } from "@aws-sdk/credential-providers";
import { mqtt, iot } from "aws-iot-device-sdk-v2";

import { appConfig } from "../config";
import { useEffect } from "react";
import { Ingredient, WaitTimesEntry } from "./types";

export default function IoT({
  setIngredients,
}: {
  setIngredients: React.Dispatch<React.SetStateAction<Ingredient[]>>;
}) {
  function handleMessageReceived(
    _: string, // topic, but unused
    payload: ArrayBuffer
  ) {
    const decoder = new TextDecoder("utf8");
    let payloadEnvelope = decoder.decode(new Uint8Array(payload));
    const payloadEnvelopeObj = JSON.parse(payloadEnvelope.toString());
    const messages = JSON.parse(payloadEnvelopeObj.msg) as WaitTimesEntry[];
    console.log(messages)
    setIngredients(function updateIngredients(ingredients) {
      // need to have this function in the dispatcher approach to have current values available in the callback
      const ingredientsSnapshot = JSON.parse(
        JSON.stringify(ingredients)
      ) as Ingredient[];
      for (const message of messages) {
        const msgIngredient = ingredientsSnapshot.find(
          (item) => item.id === message.rideId
        );
        if (msgIngredient) {
          msgIngredient.wait = String(message.wait);
          msgIngredient.inService = message.inService;
        }
      }
      return ingredientsSnapshot;
    });
  }
  async function init() {
    if (!appConfig.iot.poolId) {
      return;
    }
    const AWSConfiguration = appConfig.iot;
    console.log("IoT mounted");
    const clientId =
      "kitchen-client-" + Math.floor(Math.random() * 100000 + 1);

    const credentials = await fromCognitoIdentityPool({
      identityPoolId: AWSConfiguration.poolId,
      clientConfig: {
        region: AWSConfiguration.region,
      },
    });
    const creds = await credentials();
    let aws_region = AWSConfiguration.region;
    let aws_access_id = creds.accessKeyId;
    let aws_secret_key = creds.secretAccessKey;
    let aws_sts_token = creds.sessionToken;

    let config = iot.AwsIotMqttConnectionConfigBuilder.new_with_websockets()
      .with_clean_session(true)
      .with_client_id(clientId)
      .with_endpoint(AWSConfiguration.host)
      .with_credentials(
        aws_region,
        aws_access_id,
        aws_secret_key,
        aws_sts_token
      )
      .with_keep_alive_seconds(30)
      .build();

    const client = new mqtt.MqttClient();
    let connection = client.new_connection(config);
    console.log("Connecting...");
    connection.on("connect", () => {
      console.log("mqttClient connected");
      connection.subscribe(
        "kitchen-rides",
        mqtt.QoS.AtLeastOnce,
        handleMessageReceived
      );
    });

    connection.on("error", (error) => {
      console.error("mqttClient error:", error);
    });
  }

  useEffect(() => {
    init();
  }, []);
  return <></>;
}
